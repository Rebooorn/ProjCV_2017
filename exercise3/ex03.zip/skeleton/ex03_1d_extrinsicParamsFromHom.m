function [R,t] = ex03_1d_extrinsicParamsFromHom( H, K )
% EX03_1D_EXTRINSICPARAMSFROMHOM Calculates the extrinsic parameters from
% homography, under a given K.
    
    %% TODO!
    % Calculate r1 and r2.
    % ...
    
    % Norm r1 and r2.
    % ...
    
    
    % r3 is the cross product.
    % ...
    
    % Enforce orthonormality using SVD (which is not a given due to noise).
    % ...
    
    % R = ???;
    % t = ???;
    
end

