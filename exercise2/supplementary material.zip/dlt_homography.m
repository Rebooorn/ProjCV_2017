% Algebraic estimate of a 2D homography 
% x,x_prime source and target points, related approximately by x_prime=H*x
% assumes size(x)==[3,n], size(x)==size(x_prime)
function H = dlt_homography(x, x_prime)
	n=size(x,2);
	
	% TODO ...
	
end % function
