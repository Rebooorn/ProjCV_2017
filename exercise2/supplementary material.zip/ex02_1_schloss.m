
%
% ex02-1b
%

% Load images
F=imread('./schloss/facade.jpg');
P=imread('./schloss/photo.jpg');

% Specify corresponding points
% ...


% Compute homography
H=dlt_homography(x,x_prime);

% Compute reprojection error
reprojection_error=reprojection_error_homography(x_prime,H,x)

% Warp image and display
% ...
