clc
clear all
%Loading Image
schloss = imread('photo.jpg');
facade =  imread('facade.JPG');

%Choosing Points in Images
figure(1);
prompt = 'how many numbers to select?  ';
imshow(schloss);
n = input(prompt);
[x_schloss,y_schloss] = ginput(n); % coordinates of n points
close(1)

figure(2);
prompt = 'how many numbers to select?  ';
imshow(facade);
n = input(prompt);
[x_facade,y_facade] = ginput(n); % coordinates of n points
close(2)

%Convert to homogenous co-ordinate
        homogenous_points_schloss = ones(3,4);
        homogenous_points_schloss(1,:) = x_schloss;
        homogenous_points_schloss(2,:) = y_schloss;
        
        homogenous_points_facade = ones(3,4);
        homogenous_points_facade(1,:) = x_facade;
        homogenous_points_facade(2,:) = y_facade;

%Normalized Points of schloss
[normalized_schloss,T_schloss] = points_normalization( x_schloss,y_schloss,n);

%Normalized Points of facade
[normalized_facade,T_facade] = points_normalization( x_facade,y_facade,n);


%DLT to make A Matrix
H = DirectLinearTransformation(normalized_schloss,normalized_facade,T_schloss,...
    T_facade);


ns = H*homogenous_points_schloss;
test = ns./(repmat(ns(3,:),3,1))


%[newim, newT] = imTrans(schloss, H); %% useless function
%imshow(newim);


%%imref2d gives imagesize and world limits
sx=size(schloss);
D=imref2d(sx);

fx=size(facade);
E=imref2d(fx);

gray_schloss = rgb2gray(schloss);

gray_facade = rgb2gray(facade);

%%warp schloss on facade
T=projective2d(H');
out=imwarp(schloss,D,T,'OutputView',E);
imshow(out);
hold on;
V= imshow(facade);hold off;
G= (gray_facade==0);
G(:,1:250)=1;
G(:,650:1000)=1;
G(1:280,:)=1;
G(550:633,:)=1;
set(V,'AlphaData',G);

