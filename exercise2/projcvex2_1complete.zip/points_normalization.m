function [normalized_points,T] = points_normalization( x_points,y_points,no_points )
%Summary: This function takes the choosen points of DLT and normalizes
%them. How to nomrmalize can be found at link-a, and why to normalize can
%be found at link-b.

%Biblography: a)http://www.ele.puc-rio.br/~visao/Topicos/Homographies.pdf.
%             b)http://dsp.stackexchange.com/questions/10887/why-normalize-the-data-set-before-applying-direct-linear-transform

%Detailed: For improved estimation it is essential for DLT to normalize 
% the data sample, as follows
    % 1. The points are translated so that their centroid is at the origin.
    % 2. The points are scaled so that the average distance from the
    % origin is equal to sqrt(2).
    % 3. This transformation is applied to each of the two images
    % independently.
%Normalization is carried out be finding the Normalization Martrix T, and
%them multiplying that matrix with the choosen points. DLT is then applies
%to the normalized points. Normalization Matrix T is
% T = S*[1 0 -(mean_of_point's_x-axis);
%        0 1 -(mean_of_point's_y-axis);
%        0 1  1/S]
%Where S = (sqrt(2)*n/denominator)
%and n = no of chooosen points
%    denomicator = Sum over all n of (mean - point)^2.

        
        %Centroid = Mean
        centroid = zeros(1,2);
        
        %Calcluation mean of  Images x-axis Points 
        x_sum = sum(x_points,1);
        centroid(1,1) = x_sum/no_points;
        
        %Calcluation mean of  Images y-axis Points 
        y_sum = sum(y_points,1);
        centroid(1,2) = y_sum/no_points;
        
       %Intialition to store  {mean-point}
        norm = zeros(no_points,2);
        
       %Subratacting point from mean.
        for i = 1:no_points
            norm(i,1) = x_points(i,1) - centroid(1,1);
            norm(i,2) = y_points(i,1) - centroid(1,2);
        end
        
        %Calculating S
        denominator = 0;
        for i = 1:no_points
            denominator = denominator + sqrt((norm(i,1)^2) + (norm(i,2)^2));
        end   
        S = ((sqrt(2))*(no_points))/denominator;
        
        %Making Normaliztion Matrix 'T'
        T = zeros(3,3);
        
        T(1,:) = [1 ; 0 ; -(centroid(1,1))];
        T(2,:) = [0 ; 1 ; -(centroid(1,2))];
        T(3,:) = [1 ; 0 ; (1/S)];
        
        T = S.*T;
        
        %Converting the acquried points to homogeous co-ordinate
        homogenous_points = ones(3,no_points);
        homogenous_points(1,:) = x_points;
        homogenous_points(2,:) = y_points;
        
        
        normalized_points =  T*homogenous_points;
        
        
end


