clc;
clear all;
close all;
% codebook generation
ImageFiles = dir('E:\Sem2\Computer Projekt Vision\exercise5\images')';
arrayList={ImageFiles.name};
array_name = cell(1,2383);
for i = 1:length(array_name)
    array_name{1,i} = arrayList{1,i+2};
end

clear arrayList;
clear ImageFiles;


randomList = vl_colsubset(array_name, 1000);
random_i=[];
frames=[];
for i = 1:length(randomList);  
    random_i{1,i}=imread(fullfile('E:\Sem2\Computer Projekt Vision\exercise5\images',randomList{1,i}));
    random_i{1,i}=rgb2gray(random_i{1,i});
    random_i{1,i}=im2single(random_i{1,i});
    
    [frames{1,i},~]=vl_sift(random_i{1,i});   
end

 %% selecting 150 descriptors from each image
temp_frames = zeros(4,150000);   
j = 1;
count = 0;
for i = 1:length(randomList)
    temp = frames{1,i};
    [~,X]=size(temp);
    if X >= 150
        temp_frames(:,j:j+149) = temp(:,1:150);
        j = j + 150;
    else X < 150
        temp_frames(:,j:j+X-1) = temp(:,1:X);
        j = j + X;
        count = count + 1;
    end
end
minus = 0;
for i = 1:1000
    [~,X] = size(frames{1,i});
    if X < 150
        minus = minus + (150 - X);
    end 
end
if count ~= 0
    temp = temp_frames(4:150000 - minus);
    temp_frames = temp;
end
 temp_frames = single(temp_frames);
 clear j;
 clear X;
 clear temp;
 clear count;
 clear minus;
 clear i;
%    
%    
%     
%     