clc;
clear all;
close all;
load('siftfeatures.mat');
[centers,~] = vl_kmeans(temp_frames, 1000,'initialization','plusplus','algorithm','ann');

%% encoding



% X is a d x M matrix of sampled SIFT features, where M is the number of
% features sampled. M should be pretty large! Make sure matrix is of type
% single to be safe. E.g. single(matrix).
% K is the number of clusters desired (vocab_size)
% centers is a d x K matrix of cluster centroids. This is your vocabulary.

forest= vl_kdtreebuild(centers,'distance','l2');
frames_all=cell2mat(frames);
frames_all=single(frames_all);

[index, ~] = vl_kdtreequery(forest,centers, ...
                                    temp_frames);%Query the tree -Exact nearest neighbors
%% Bag of words

%%  classification 
random_names = cell(1,1000);
for i = 1:1000
    random_names{1,i} = randomList{1,i};
    random_names{1,i}= regexprep(random_names(1,i),'.jpg','');
end

pos= textread('horse_val.txt','%q')';
neg= textread('background_val.txt','%q')';

% Pack the data into a matrix with given data in one column and random
% sample in another

label=[];
for i = 1:length(random_names)
    
    temp_1 = strcmp(pos,random_names{1,i});
    temp_2 = strcmp(neg,random_names{1,i});
    a = logical(find(temp_1 == 1));
    b = logical(find(temp_2 == 1));
    if a == 1
        label(1,i) = 1;
    elseif  b == 1
        label(1,i) = -1;
    end
end


C = 1 ;
                       
lambda = 1 / (C * 1000 );

[Weight, Offset]=vl_svmtrain(BoW,label,lambda,'solver' ,'sdca','BiasMultiplier',1);
% trains a linear Support Vector Machine (SVM) from the data vectors X 
% and the labels Y. X is a D by N matrix, with one column per example 
% and D feature dimensions (SINGLE or DOUBLE). Y is a DOUBLE vector with
% N elements with a binary (-1 or +1) label for each training point. To a 
% first order approximation, the function computes a weight vector W and
% offset B such that the score W'*X(:,i)+B has the same sign of LABELS(i) for all i.
 

[scores]= Weight'*BoW + Offset;%test classifier 



% Visualize the precision-recall curve for test set
figure(1) ; clf ;
vl_pr(label, scores);
[precision,recall,info]=vl_pr(label, scores); % computes the precision-recall (PR) curve.
%                             % LABELS-N are the ground truth labels, greather than zero
%                             % for a positive sample and smaller than zero for a negative
%                             % one. SCORES are the scores of the samples obtained from
%                             % a classifier, where lager scores should correspond to 
%                             % positive samples.
figure(2); clf;                            
vl_roc(label,scores);                         
fprintf('Test AP: %.2f\n', info.ap) ;
fprintf('Test auc: %.2f\n', info.auc) ;
[~,perm] = sort(scores,'descend') ;

fprintf('Correctly retrieved in the top 50: %d\n',sum(label(perm(1:50)) > 0)) ;

% sorted score
% [temp,index] = sort(scores,'descend');
% sorted_scores = zeros(1,50);
% sorted_array_label = zeros(1,50);
% for i = 1:50
%     sorted_scores(1,i) = temp(1,i);
%     temp_1 = index(1,i);
%     sorted_array_label(1,i) = label(1,temp_1); 
% end
% [recall_sorted,precision_sorted] = vl_pr(sorted_array_label, sorted_scores);
% vl_pr(sorted_array_label, sorted_scores);
% 
% fprintf('AP: %.2f\n', info.ap) ;
% fprintf('auc: %.2f\n', info.auc) ;

% % fprintf('Correctly retrieved in the top 50: %d\n',sum(sorted_array_label(index(1:50)) > 0)) ;
% vl_roc(sorted_array_label, sorted_scores);


clear pos;
clear neg;
clear temp_1;
clear temp_2;
clear info;
clear i;
clear j;
clear x;
clear Weight;
clear Offset;
clear perm;
clear ans;





