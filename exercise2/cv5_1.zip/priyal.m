%Visual Image Recognition

% run('/home/cip/2015/uw88ymiq/projcv/vlfeat-0.9.20-bin/vlfeat-0.9.20/toolbox/vl_setup')
close all;
clc;
clear all;

recompute_centers = false;
recompute_training = true;

load('background_train.txt') 
load('background_val.txt')
load('horse_train.txt')
load('horse_val.txt')

N_input = 2000;%changed here
N_features = 150;
numClusters = 1000;
C = 10;

if (recompute_centers == true)
    trainning_subset = vl_colsubset([background_train' horse_train'], N_input);
    N_input = length(trainning_subset);
    

    big_f = cell(N_input,1);
    parfor i = 1:N_input

        %format 000000.jpg
        impath = sprintf('images/%06d.jpg', trainning_subset(i));
        img = im2single(rgb2gray(imread(impath)));
        F = vl_sift(img);
        big_f{i} =  vl_colsubset(F, N_features);

        %{
        F = VL_SIFT(I) computes the SIFT frames [1] (keypoints) F of the image I.
        Each column of F is a feature frame and has the format [X;Y;S;TH],
        where X,Y is the (fractional) center of the frame, S is the scale and TH
        is the orientation (in radians). 
        %}
        %get only 150 random descriptors out of F
    end

    %conncatenate cell to matrix

    big_f_m = horzcat(big_f{1:N_input});

    %perform kmeans

    
    [centers, ~] = vl_kmeans(big_f_m, numClusters, 'Initialization', 'plusplus', 'Algorithm', 'ANN');

    save('centers.mat', 'centers');

else
   load('centers.mat');
end

forest = vl_kdtreebuild(centers);

if(recompute_training)

    %vector quantization


    N_back = length(background_train); 
    N_horse = length(horse_train);
    
    X = cell(N_back+N_horse,1);
    Y = cell(N_back+N_horse,1);

    %background
    parfor i = 1:N_back
        impath = sprintf('images/%06d.jpg', background_train(i));
        img = im2single(rgb2gray(imread(impath)));
        F = vl_sift(img);
        indexes = vl_kdtreequery(forest, centers, F);
        %h = hist(indexes, 1:numClusters);
        h = vl_binsum(zeros(1, numClusters),1,indexes)
        X{i} = h'./(norm(h)+eps);
        Y{i} = -1;
    end

    %horses
    parfor i = 1:N_horse
        impath = sprintf('images/%06d.jpg', horse_train(i));
        img = im2single(rgb2gray(imread(impath)));
        F = vl_sift(img);
        indexes = vl_kdtreequery(forest, centers, F);%max descrp
        %h = hist(indexes, 1:numClusters);
        h = vl_binsum(zeros(1, numClusters),1,indexes)
        X{i+N_back} = h'./(norm(h)+eps);
        Y{i+N_back} = 1;
    end

    X_m = horzcat(X{1:(N_back+N_horse)});
    Y_v = horzcat(Y{1:(N_back+N_horse)});

    weigths = zeros(N_back+N_horse,1);
    weigths(Y_v==1) = 1;
    weigths(Y_v==-1) = .1;
    %svm
    %{
    [W B] = VL_SVMTRAIN(X, Y, LAMBDA) trains a linear Support Vector Machine (SVM) 
    from the data vectors X and the labels Y. X is a D by N matrix, with one column 
    per example and D feature dimensions (SINGLE or DOUBLE). Y is a DOUBLE vector 
    with N elements with a binary (-1 or +1) label for each training point. 
    %}
    lambda = 1/(C*(N_back+N_horse));
    [W, B] = vl_svmtrain(X_m, Y_v, lambda, 'solver', 'sdca', 'BiasMultiplier', 1,'Weights', weigths); %try to use weights for svm Weights
    save('svm.mat', 'W', 'B')
else
    load('svm.mat');
end

%classification

N_horse = length(horse_val); 
N_back = length(background_val);

horse_target = cell(N_horse,1);
background_target = cell(N_back,1);

parfor i = 1:N_horse
    %horse
    impath = sprintf('images/%06d.jpg', horse_val(i));
    img = im2single(rgb2gray(imread(impath)));
    F = vl_sift(img);
    indexes = vl_kdtreequery(forest, centers, F);
    %h = hist(indexes, 1:numClusters);
    h = vl_binsum(zeros(1, numClusters),1,indexes)
    horse_target{i} = (dot(h'./(norm(h)+eps), W) + B); %W'*X(:,i)+B
end
horse_target_v = cat(1, horse_target{1:N_horse});

horse_target_v(horse_target_v>=0)=1;
horse_target_v(horse_target_v<0)=-1;
parfor i = 1:N_back   
    %background
    impath = sprintf('images/%06d.jpg', background_val(i));
    img = im2single(rgb2gray(imread(impath)));
    F = vl_sift(img);
    indexes = vl_kdtreequery(forest, centers, F);
    %h = hist(indexes, 1:numClusters);
    h = vl_binsum(zeros(1, numClusters),1,indexes)
    background_target{i} = (dot(h'./(norm(h)+eps), W) + B);
end


background_target_v = cat(1, background_target{1:N_back});



background_target_v(background_target_v>=0)=1;
background_target_v(background_target_v<0)=-1;


%evaluation
true_positive = mean(horse_target_v==1)
true_negtive = mean(background_target_v==-1)


labels = [ones(N_horse,1); -ones(N_back,1)];
scores = [horse_target_v; background_target_v];
figure

vl_pr(labels, scores);%, 'NormalizePrior', 1);
[~,~,INFO]=vl_pr(labels, scores);%, 'NormalizePrior', 1);
figure
subplot(1,2,2);
vl_roc(labels, scores);


